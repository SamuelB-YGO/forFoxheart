--大邪神の儀式
function c60369732.initial_effect(c)
	aux.AddRitualProcGreaterCode(c,62420419)
end
