--金色の魔象
function c54622031.initial_effect(c)
	--fusion material
	c:EnableReviveLimit()
	aux.AddFusionProcCode2(c,29491031,66672569,true,true)
end
