--双頭の雷龍
function c54752875.initial_effect(c)
	--fusion material
	c:EnableReviveLimit()
	aux.AddFusionProcCodeRep(c,31786629,2,true,true)
end
