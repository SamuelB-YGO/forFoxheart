--スチームジャイロイド
function c5368615.initial_effect(c)
	--fusion material
	c:EnableReviveLimit()
	aux.AddFusionProcCode2(c,18325492,44729197,true,true)
end
