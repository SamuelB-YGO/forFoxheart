﻿namespace WindBot.Game.AI.Enums
{
    public enum PreventActivationEffectInBattle
    {
        Deskbot009 = 25494711,
        ArchfiendBlackSkullDragon = 45349196,
        FrightfurChimera = 83866861,
        GladiatorBeastNerokius = 29357956,
        GemKnightCitrine = 67985943,
        FrightfurSheep = 57477163,
        SamuraiDestroyer = 40509732,
        ArmadesKeeperOfBoundaries = 88033975,
        NumberS39UtopiaTheLightning = 56832966,
    }
}
