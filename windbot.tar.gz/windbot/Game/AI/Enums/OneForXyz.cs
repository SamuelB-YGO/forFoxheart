﻿namespace WindBot.Game.AI.Enums
{
    public enum OneForXyz
    {
        ZoodiacThoroughblade = 77150143,
        ZoodiacViper = 31755044,
        ZoodiacCluckle = 20155904,
        ZoodiacRabbina = 4367330,
        ZoodiacRam = 4145852,
        ZoodiacMarmorat = 78872731,
        ZoodiacTigress = 11510448,
        ZoodiacHammerkong = 14970113,
        ZoodiacLyca = 41375811,
        ZoodiacDrancia = 48905153,
        ZoodiacBoarbow = 74393852,
        ZoodiacBroadbull = 85115440,
        Number62 = 31801517,
        GalaxyEyesCipherDragon = 18963306,
        Number107 = 88177324,
        CyberDragonNova = 58069384,
        Number39 = 84013237
    }
}
