﻿namespace WindBot.Game.AI
{
    public enum ExecutorType
    {
        Summon,
        SpSummon,
        Repos,
        MonsterSet,
        SpellSet,
        Activate,
        SummonOrSet,
        GoToBattlePhase,
        GoToMainPhase2,
        GoToEndPhase
    }
}